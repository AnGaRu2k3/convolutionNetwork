#!/bin/bash

pip install torch torchvision matplotlib numpy PyYAML torchsummary
# Example runs with different configurations
# Run 1: ANN model on MNIST and cnn_fashionmnist.pt
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type ann --dataset MNIST --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/ann_mnist.pt
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type ann --dataset FashionMNIST --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_fashionmnist.pt
# caltech101
# Không sử dụng pretrained model, 
python main.py --train --device cuda --model netConfigs/3base_residual.yaml --model-type cnn --dataset Caltech101 --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_caltech101_no_pretrained_3base_residual.pt
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type cnn --dataset Caltech101 --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_caltech101_no_pretrained_3base.pt
python main.py --train --device cuda --model netConfigs/4base.yaml --model-type cnn --dataset Caltech101 --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_caltech101_no_pretrained_4base.pt

