#!/bin/bash

pip install torch torchvision matplotlib numpy PyYAML torchsummary
# Example runs with different configurations
# Run 1: ANN model on MNIST
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type ann --dataset MNIST --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/ann_mnist.pt

# Run 2: CNN model on FashionMNIST
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type cnn --dataset FashionMNIST --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_fashionmnist.pt

# Run 3: ANN model on Caltech101
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type ann --dataset Caltech101 --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/ann_caltech101.pt

# Run 4: CNN model on Caltech256
python main.py --train --device cuda --model netConfigs/3base.yaml --model-type cnn --dataset Caltech256 --epochs 50 --batch-size 64 --base-lr 0.005 --target-lr 0.00001 --warmup-epochs 5 --save-path models/cnn_caltech256.pt